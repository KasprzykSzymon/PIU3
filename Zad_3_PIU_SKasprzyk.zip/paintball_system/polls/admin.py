from django.contrib import admin
from .models import CourtReservation

@admin.register(CourtReservation)
class CourtReservationAdmin(admin.ModelAdmin):
    list_display = ('num_people', 'reservation_date', 'reservation_time', 'user')
    list_filter = ('num_people', 'reservation_date')