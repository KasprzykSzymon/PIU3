from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_page_view, name='home_page'),
    path('rezerwacja/', views.reservation_view, name='reservation'),
    path('reserve_action/', views.reserve_action, name='reserve_action'),
    path('kontakt/', views.contact_view, name='contact'),
    path('zaloguj_sie/', views.sign_in_view, name='sign_in'),
    path('rejestracja/', views.register_view, name='register'),
    path('profile/', views.profile_view, name='profile'),
    path('logout/', views.logout_view, name='logout'),
    path('edytuj_profil/', views.edit_profile_view, name='edit_profile'),
] 